//index.js
//获取应用实例
var app = getApp();
Page({
    data: {
      indexmenu: [],
      imgUrls: []
    },
    onLoad: function() {
      this.fetchData();
      wx.getLocation({
        type: 'wgs84',
        success: function (res) {
          var latitude = res.latitude
          var longitude = res.longitude
          var speed = res.speed
          var address = res.address
          var accuracy = res.accuracy
        }
      }),
      this.setData({
        hasLogin: app.globalData.hasLogin
      })
    },
    login: function() {
      var that = this
      wx.login({
        success: function(res) {
          app.globalData.hasLogin = true
          that.setData({
            hasLogin: true
          })
          that.update()
        }
      })
    },
    
    fetchData: function() {
      this.setData({
        indexmenu: [
          //{
          //   'icon': './../../images/icon_01.png',
          //   'text': '信息列表',
          //   'url': 'list'
          // }, 
          {
            'icon': './../../images/icon_03.png',
            'text': '服务集市',
            'url': 'service'
          }, 
          // {
          //   'icon': './../../images/icon_05.png',
          //   'text': '信息搜索',
          //   'url': 'service'
          // }, 
          {
            'icon': './../../images/icon_07.png',
            'text': '信息发布',
            'url': 'information'
          }, {
            'icon': './../../images/icon_09.png',
            'text': '问题反馈',
            'url': 'question'
          }, {
            'icon': './../../images/icon_11.png',
            'text': '物业服务',
            'url': 'property'
          }
          // {
          //   'icon':'./../../images/icon_13.png',
          //   'text':'入驻申请',
          //   'url':'apply'
          // }
        ],
        imgUrls: [
          //'../../images/banner_02.jpg',
          '../../images/gclub_banner_1.jpg',
          '../../images/gclub_banner_3.jpg'
        ]
      })
    },
    changeRoute: function(url) {
      wx.navigateTo({
          url: `.. /${url}/${url}`
    })
  },
  onReady:function(){
    //生命周期函数--监听页面显示
        //console.log('onReady');
        },
        onShow: function() {
          //生命周期函数--监听页面显示
          // console.log('onShow');
        },
        onHide: function() {
          //生命周期函数--监听页面隐藏
          // console.log('onHide');
        },
        onUnload: function() {
          //生命周期函数--监听页面卸载
          // console.log('onUnload');
        },
        onPullDownRefresh: function() {
          //页面相关事件处理函数--监听用户下拉动作
          // console.log('onPullDownRefresh');
        },
        onReachBottom: function() {
          //页面上拉触底事件的处理函数
          // console.log('onReachBottom');
        }
      })
import util from './../../utils/util.js';
Page({
  data: {
    showtab:0,  //顶部选项卡索引
    showtabtype:'', //选中类型
    showfootertab:0,  //底部标签页索引
    tabnav:{},  //顶部选项卡数
    // questionsall:[],  //所有问题
    // questions:[], //问题列表
    mobile:'',
    name:'',
    inputText:'',
    showquestionindex:null, //查看问题索引,
    uploadimgs:[], //上传图片列表
    editable: false //是否可编辑
  },
  onLoad: function () {
    this.setData({
      //tabnav:{
      //   tabnum:5,
      //   tabitem:[
      //     {
      //       "id":0,
      //       "type":"",
      //       "text":"全部"
      //     },
      //     {
      //       "id":1,
      //       "type":"A",
      //       "text":"服务咨询"
      //     },
      //     {
      //       "id":2,
      //       "type":"B",
      //       "text":"空间查询"
      //     },
      //     {
      //       "id":3,
      //       "type":"C",
      //       "text":"活动咨询"
      //     },
      //     {
      //       "id":4,
      //       "type":"D",
      //       "text":"入驻信息"
      //     }
      //   ]
      // },
      uploadimgs:[]
    })
    //this.fetchQuestions();
  },
  inputPhone: function (e) {
    this.setData({
      mobile: e.detail.value
    })
  },
  inputName: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  inputText: function (e) {
    this.setData({
      inputText: e.detail.value
    })
  },
  chooseImage:function() {
    let _this = this;
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#f7982a",
      success: function(res) {
        if (!res.cancel) {
          if(res.tapIndex == 0){
            _this.chooseWxImage('album')
          }else if(res.tapIndex == 1){
            _this.chooseWxImage('camera')
          }
        }
      }
    })
  },
  chooseWxImage:function(type){
    let _this = this;
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: function (res) {
        _this.setData({
          uploadimgs: _this.data.uploadimgs.concat(res.tempFilePaths)
        })
      }
    })
  },
  editImage:function(){
    this.setData({
      editable: !this.data.editable
    })
  },
  deleteImg:function(e){
    console.log(e.currentTarget.dataset.index);
    const imgs = this.data.uploadimgs
    Array.prototype.remove = function(i){
      const l = this.length;
      if(l==1){
        return []
      }else if(i>1){
        return [].concat(this.splice(0,i),this.splice(i+1,l-1))
      }
    }
    this.setData({
      uploadimgs: imgs.remove(e.currentTarget.dataset.index)
    })
  },
  questionSubmit : function (e){
    console.log('form发生了submit事件，电话号码为：', this.data.mobile, '名称为', this.data.name, this.data.inputText)
    wx.request({
      url: "https://linda.gclub.cn/ajax/createpost",
      data: util.json2Form({
        title: '发布信息',
        mobile: this.data.mobile,
        content: this.data.inputText 
        }),  
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: {"content-type":"application/x-www-form-urlencoded"}, 
      // 设置请求的 header
      success: function (res) {
        console.log(JSON.stringify(res));
        wx.showToast({
          title: '成功',
          icon: 'success',
          duration: 2000
        })
        wx.redirectTo({
          url: '../index/index',
          complete: function (res) {
            console.log(res) 
          }
        })
      },
      fail: function (res) {
        console.log(JSON.stringify(res));
      },
      complete: function () {
        // complete
      }
    })
  },
  callContact: function(e){  //拨打电话
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.ponenumber
    })
  }
})

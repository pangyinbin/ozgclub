Page({
  data: {
    list: {}
  },
  onReady: function () {
    wx.setNavigationBarTitle({
      title: this.title
    })
  },
  onLoad: function () {
    var that = this 
    wx.request({
      url: 'http://ozgclub.me/ajax/postlist',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
         that.setData({
           list: res.data
         })
         console.log(res.isSuccess)
      }
    })
  }
})

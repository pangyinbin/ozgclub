// var app = getApp()
// Page({
//   onLoad: function () {
//     this.setData({
//       hasLogin: app.globalData.hasLogin
//     })
//   },
//   data: {},
//   login: function () {
//     var that = this
//     wx.login({
//       success: function (res) {
//         app.globalData.hasLogin = true
//         that.setData({
//           hasLogin: true
//         }
//         that.update()
//       }
//     })
//   }
// })

var API_URL = "https://linda.gclub.cn/ajax/weixinlogin";
Page({
  data: {
    iv: null,
    code: null,
    encryptedData: null
  },
  onLoad: function() {
    //console.log("iv");
    wx.login({ //login流程
      success: function(res) { //登录成功
        if (res.code) {
          var code = res.code;
          if (code) {
            console.log('获取用户登录凭证：' + code);
          } else {
            console.log('获取用户登录态失败：' + res.errMsg);
          }
          // wx.getUserInfo({ //getUserInfo流程
          //   success: function(res2) { //获取userinfo成功
          //     console.log('res2' + res2.iv);
          //     var encryptedData = encodeURIComponent(res2.encryptedData); //一定要把加密串转成URI编码
          //     var iv = res2.iv;
          //     console.log(iv);
          //     //请求自己的服务器
          //     Login(code, encryptedData, iv);
          //   }
          // })
          wx.showToast({
            title: '登陆成功',
            icon: 'success',
            duration:2000
          })
          wx.redirectTo({
            url: '../information/information',
              complete: function (res) {
                console.log(res)
              }
          })
        } else {
          console.log('获取用户登录态失败！' + res.errMsg);
          wx.showToast({
            title: '登陆失败',
            icon: 'success',
            duration: 2000
          })
          wx.redirectTo({
            url: '../index/index',
          })
          
        }
      }
    });
  },

})
function getlocationwx () {
  console.log('geetlocationwx')
　　var that = this;
　　wx.getLocation({
  　　　　success: function (res) {
    　　　　　　wx.request({
      　　　　　　　　url: 'http://api.map.baidu.com/geocoder/v2/?ak=btsVVWf0TM1zUBEbzFz6QqWF&callback=renderReverse&location=' + res.latitude + ',' + res.longitude + '&output=json&pois=1', data: {},
      　　　　　　　　header: { 'Content-Type': 'application/json' },
      　　　　　　　　success: function (ops) {
        　　　　　　　　　　console.log(ops.data)
      　　　　　　　　}
    　　　　})
    　　}
  })
}


function Login(code, encryptedData, iv) {
  console.log('code=' + code + '&encryptedData=' + encryptedData + '&iv=' + iv);
  //创建一个dialog
  wx.showToast({
    title: '正在登录...',
    icon: 'loading',
    duration: 10000
  });
  //请求服务器
  wx.request({
    url: API_URL,
    data: {
      code: code,
      encryptedData: encryptedData,
      iv: iv
    },
    method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
    header: {
      'content-type': 'application/json'
    }, // 设置请求的 header
    success: function(res) {
      // success
      wx.showToast({
        title: '登陆成功',
        icon: 'loading',
        duration: 10000
      });
      wx.hideToast();
      console.log('服务器返回' + res.data);

    },
    fail: function() {
      // fail
      //wx.hideToast();
    },
    complete: function() {
      // complete
    }
  })
}
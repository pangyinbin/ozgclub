Page({
  data: {
  },
  bindPickerChange:function(e){
    console.log('选择的小区为',e.detail.value)
    this.setData({
      index:e.detail.value
    })
  },
  onLoad: function () {
    var that= this
    var list= []
    wx.request({
      url: 'https://linda.gclub.cn/ajax/blocklist',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        that.setData({
          list: res.data.data.value
        })
        console.log(res.data.data)
      }
    })
  }
})